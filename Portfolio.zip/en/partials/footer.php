<footer class="page-footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <p>Copyright
                    <script>
                    document.write(new Date().getFullYear())
                    </script> &copy; <a href="">SaidHAMMANE</a>
                </p>
            </div>
            <div class="col-sm-6">
                <div class="socials">
                    <a class="social-item" href="javascript:void(0)" onclick="copyUsername('overload#6735')"><i
                            class="fa-brands fa-discord"></i></a>
                    <a class="social-item" href="mailto:said.hammane1@gmail.com"><i
                            class="fa-regular fa-envelope"></i></a>
                    <a class="social-item" href="https://www.instagram.com/said.hammane/" target="_blank"><i
                            class="fa-brands fa-instagram"></i></a>
                    <a class="social-item" href="https://www.linkedin.com/in/said-hammane-07926b1a0/" target="_blank"><i
                            class="fa-brands fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>