<!-- core  -->
<script src="./assets/vendors/jquery/jquery-3.4.1.js"></script>
<script src="./assets/vendors/bootstrap/bootstrap.bundle.js"></script>
<!-- bootstrap 3 affix -->
<script src="./assets/vendors/bootstrap/bootstrap.affix.js"></script>
<script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
<script src="./assets/js/common.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>